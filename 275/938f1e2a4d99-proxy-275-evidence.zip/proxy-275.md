# Windows proxy import hang: found cause (task 275)

Outcome: evidence only, by owner decision. Issue #279 removes Headroom and optimization from AgentQ, so the proxy repair stops here and no code merges. All observations are from one Windows 11 host on 2026-11-06, release 0.10.0.

## Found cause

The proxy inherits low priority from the Task Scheduler start of the service, and its start reads thousands of files. At that priority the start did not finish in any measured run.

1. The unit XML that CoreQ writes has no `Priority` element, so Task Scheduler applies its default, `Priority 7`.
2. The service and the proxy read below-normal CPU, low I/O and low memory priority:

   ```text
   agentq.exe  service run   class=0x4000 ioPriority=1 pagePriority=2
   python3.12  proxy         class=0x4000 ioPriority=1 pagePriority=2
   powershell  interactive   class=0x20   ioPriority=2 pagePriority=5
   ```

3. `headroom/cli/proxy.py` imports `transformers` as a required module. `create_import_structure_from_path` in `transformers/utils/import_utils.py` then opens and reads nearly all of its 2719 Python files. A stack dump at 20 s of a normal-priority run shows this frame.

The headroom hard watchdog arms only after these imports, so it cannot end a worker that hangs in them. The service replaced only an exited worker, so a live but silent worker stayed in place. `agentq status` did not show the proxy.

## Evidence

Same interpreter and files, at the same time (21:51):

| Measure | Service worker (low) | Diagnostic probe (normal) |
|---|---|---|
| CPU | 1 s after 70 s | 6 s after 7 s |
| Read operations | about 1.5 per second | about 275 per second |

Controlled run: import of `transformers` only, with a 120 s budget. The kill overran the budget, because the runner was also at low priority.

| Round | Low (Task Scheduler state) | Normal |
|---|---|---|
| 1 | not finished after 174 s | 20.57 s |
| 2 | not finished after 352 s | 19.26 s |

Service log: the last `Hard watchdog armed` line is 17:42:43. The worker started after the 20:49 watchdog exit logged nothing until the service restart. A worker started at 21:35 held 92 MB and no listener at 21:47.

## What is not proven

- **Priority is not the only factor.** A candidate build that raised the service and its worker to normal (`class=0x20 io=2 page=5`, read back) still started slowly: `Hard watchdog armed` at 128 s in one run, and the first HTTP 200 at 562 s in another. A third gave no reply for 320 s before its worker was killed by a defect in that candidate.
- **Host load is measured only afterwards.** At 22:41: 1071 MB free memory, 1775 MB free of a 51110 MB commit limit, 9392 pages/s, disk 95% idle. The share of priority and of load is not separated. A third-party process manager runs on this host; its effect was not measured.
- **The 442 s `/v1/models` request is inferred, not reproduced.** The log has no line from 20:44:01 to 20:48:43, and the watchdog dump shows the main thread in plain `starlette/datastructures.py`, with no lock wait, so this looks like starvation rather than a deadlock. The same window logged upstream `httpx.ConnectTimeout`. Resource samples have a hole from 20:11 to 21:10, so no memory sample covers that stall.

## Live Codex turn through the candidate

The candidate ran in a temporary install with its own data and port, from a parent lowered to the Task Scheduler state. One `codex exec` (codex-cli 0.162.1, native login, per-command provider override, 21,785 tokens) returned `READY` with exit 0, and the proxy logged `POST /v1/responses status=200`. No client configuration or live install changed. The installed unit itself was not run with the candidate.

## State after this task

- Codex on this host reads `routing=direct`, `desired=disabled`, `configuration=detached`. This task did not change that.
- Acceptance A2 and A3 are not delivered, by owner decision. A silent proxy stays invisible in `agentq status` on the released version until #279 removes it.
- PR #280 was opened before the worker read the decision and was closed without merge. Commit `da34c672f64bcc8ee9a7f3aa23c089f159f73c21` on branch `taskq-275` keeps the unmerged candidate for reference.

## For the owner

CoreQ writes the unit without `Priority`, so any other product with a CoreQ Windows unit may inherit the same state, and this does not end with the removal of Headroom. This task did not inspect those products.
